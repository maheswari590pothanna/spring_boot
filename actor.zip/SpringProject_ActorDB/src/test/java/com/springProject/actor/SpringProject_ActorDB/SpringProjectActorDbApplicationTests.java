package com.springProject.actor.SpringProject_ActorDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectActorDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
