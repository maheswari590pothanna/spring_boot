package com.springProject.actor.SpringProject_ActorDB.exception;

public class UserNotFoundByIdException extends RuntimeException{
	private final String message;

	public UserNotFoundByIdException(String message) {
		//super();
		this.message = message;
	}
	public String getMessage()
	{
		return message;
	}
	

}
