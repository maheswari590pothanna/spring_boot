package com.springProject.actor.SpringProject_ActorDB.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springProject.actor.SpringProject_ActorDB.entity.Actor;

@Service
public interface ActorService {
	
	public Actor addActor(Actor actor);
	
	public List<Actor> findAllActors();

	public Actor findActorById(int actorId);

	public Actor deleteActorById(int actorId);

	public Actor updateActorById(Actor actor);

}
