package com.springProject.actor.SpringProject_ActorDB.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.actor.SpringProject_ActorDB.entity.Actor;
import com.springProject.actor.SpringProject_ActorDB.exception.UserNotFoundByIdException;
import com.springProject.actor.SpringProject_ActorDB.repository.ActorRepository;
import com.springProject.actor.SpringProject_ActorDB.service.ActorService;

@Service
public class ActorServiceImpl implements ActorService {

	@Autowired
	private ActorRepository actorRepository;

	@Override
	public Actor addActor(Actor actor) {
		return actorRepository.save(actor);

	}

	@Override
	public List<Actor> findAllActors() {
		List<Actor> actors = actorRepository.findAll();

		if (actors.isEmpty()) {
			return null;
		} else {
			return actors;
		}
	}

	@Override
	public Actor findActorById(int actorId) {
//		 return actorRepository.findById(actorId).orElseThrow(()->new
//		 RuntimeException("failed to find user"));
		Optional<Actor> optional = actorRepository.findById(actorId);

		if (optional.isPresent()) {
			Actor actor = optional.get();
			return actor;
		} else {
			throw new RuntimeException("failed to find actor");
		}

	}

	@Override
	public Actor deleteActorById(int actorId) {
		// using functional programming
		return actorRepository.findById(actorId).map(actor -> {
			actorRepository.delete(actor);
			return actor;

		}).orElseThrow(() -> new RuntimeException("failed to delete the actor"));
	}

	@Override
	public Actor updateActorById(Actor actor) {
		// return actorRepository.save(actor);

		// when we r having multiple relationship between the tables

		Optional<Actor> optional = actorRepository.findById(actor.getActorId());
		if (optional.isPresent()) {
			Actor exActor = optional.get();
			exActor.setActorName(actor.getActorName());
			exActor.setAge(actor.getAge());
			exActor.setIndustry(actor.getIndustry());
			exActor.setNationality(actor.getNationality());

			return actorRepository.save(exActor);
		} else {
			throw new UserNotFoundByIdException("failed to update the actor");
		}

	}
}

	// return actorRepository.findById(actorId).ifPresentOrElse(actor ->
	// actorRepository.delete(actor),()->{
//			new RunTimeException("failed to delete actor");
//		});	
////		

//		Optional<Actor> optional = actorRepository.findById(actorId);
//
//		if (optional.isPresent()) {
//			Actor actor = optional.get();
//			actorRepository.delete(actor);
//			return actor;
//		} else {
//			throw new RuntimeException("failed to delete actor");
//		}


