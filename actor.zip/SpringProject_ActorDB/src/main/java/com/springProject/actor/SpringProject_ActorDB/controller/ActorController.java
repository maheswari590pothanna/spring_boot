package com.springProject.actor.SpringProject_ActorDB.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.springProject.actor.SpringProject_ActorDB.entity.Actor;
import com.springProject.actor.SpringProject_ActorDB.exception.UserNotFoundByIdException;
import com.springProject.actor.SpringProject_ActorDB.service.ActorService;
import com.springProject.actor.SpringProject_ActorDB.utility.ResponseStructure;

//@Controller
//@ResponseBody
@RestController
public class ActorController {
	@Autowired
	private ActorService actorService;
// ActorService ac=new ActorServiceImpl();

//	private Map<String, Object> sendResponse(int status,String message,Actor data){
//		return Map.of(
//				"status",status,
//				"message",message,
//				"data",data);
//				
//				
//	}
	// @RequestMapping(value = "/actors", method = RequestMethod.POST)
//	@PostMapping("/actors")
//	public Actor addActor(@RequestBody Actor actor) {
//		return actorService.addActor(actor);
//	}
//		@PostMapping("/actors")
//		public Map<String,Object> addActor(@RequestBody Actor actor){
//			actor=actorService.addActor(actor);
//			return this.sendResponse(201,"user created", actor);
//		}
	
	@PostMapping("/actors")
	public ResponseStructure<Actor> addActor(@RequestBody Actor actor)
	{
		actor =actorService.addActor(actor);
		//return ResponseStructure.create(201,"user created",actor);
		return ResponseStructure.create(HttpStatus.CREATED.value(),"user created",actor);
	}
	
	
	

	// @RequestMapping(value = "/actors", method = RequestMethod.GET)
//	@GetMapping("/actors")
//	public List<Actor> findAllActors() {
//		return actorService.findAllActors();
//	}
	@GetMapping("/actors")
	public ResponseStructure<List<Actor>> findAllActors() {
	List<Actor> actors	= actorService.findAllActors();
	return ResponseStructure.create(HttpStatus.FOUND.value(), "user found", actors);
	}
	

//	@GetMapping("find-actor")
//	public Actor findActorById(@RequestParam int actorId) {
//		return actorService.findActorById(actorId);
//	}
	@GetMapping("find-actor")
	public ResponseEntity<ResponseStructure<Actor>> findActorById(@RequestParam int actorId) {
		Actor actor=actorService.findActorById(actorId);
		//return ResponseStructure.create(HttpStatus.FOUND.value(), "user found", actor);
	return ResponseEntity
			.status(HttpStatus.FOUND)
			.body(ResponseStructure.create(HttpStatus.FOUND.value(), "user found", actor));
	}

	
	
	// delete the existing Actor
	// req:actor id
	// output:Actor
//	@DeleteMapping("/actors")
//	public Actor deleteActorById(@RequestParam int actorId) {
//		return actorService.deleteActorById(actorId);
//	}
	@DeleteMapping("/actors")
	public ResponseStructure<Actor> deleteActorById(@RequestParam int actorId) {
		Actor actor= actorService.deleteActorById(actorId);
		return ResponseStructure.create(HttpStatus.OK.value(), "user deleted", actor);
	}

	// update the existing actor
	// req: Actor object
	// output:Actor object
//	@PutMapping("/update-actor")
//	public Actor updateActorById(@RequestBody Actor actor) {
//		return actorService.updateActorById(actor);
//
//	}
	@PutMapping("/update-actor")
	public ResponseStructure<Actor> updateActorById(@RequestBody Actor actor) {
		 actor= actorService.updateActorById(actor);
		 return ResponseStructure.create(HttpStatus.OK.value(), "user updtaed", actor);
		

	}

//	@ExceptionHandler
//	public Map<String, Object> handleuserNotFoundById(UserNotFoundByIdException ex) {
//		Map<String, Object> response = new HashMap<String, Object>();
//		response.put("status", 404);
//		response.put("message", ex.getMessage());
//		response.put("rootcause","user not found by the given id");
//		
//		return response;
		//return Map.of("status", 404, "message", ex.getMessage(), "rootcause", "user not found by the given id");

	}


