package com.springProject.actor.SpringProject_ActorDB.exception;

public class ActorsNotFoundException {
	private final String message;

	public ActorsNotFoundException(String message) {
		//super();
		this.message = message;
	}
	public String getMessage()
	{
		return message;
	}

}
