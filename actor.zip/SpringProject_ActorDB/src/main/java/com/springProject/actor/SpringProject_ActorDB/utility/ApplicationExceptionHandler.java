package com.springProject.actor.SpringProject_ActorDB.utility;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.springProject.actor.SpringProject_ActorDB.exception.ActorsNotFoundException;
import com.springProject.actor.SpringProject_ActorDB.exception.UserNotFoundByIdException;

@RestControllerAdvice
public class ApplicationExceptionHandler {
	//@ExceptionHandler
//	public Map<String, Object> handleuserNotFoundById(UserNotFoundByIdException ex) {
//		Map<String, Object> response = new HashMap<String, Object>();
////		response.put("status", 404);
////		response.put("message", ex.getMessage());
////		response.put("rootcause","user not found by the given id");
////		
////		return response;
//		return Map.of("status", 404, "message", ex.getMessage(), "rootcause", "user not found by the given id");
//
//	}
   @ExceptionHandler
	public ErrorStructure handleuserNotFoundById(UserNotFoundByIdException ex)
	{
		//return ErrorStructure.create(404, ex.getMessage(),"Actor not found by the given Id");
		return ErrorStructure.create(404, ex.getMessage(),"Actor not found by the given Id");

	}
	@ExceptionHandler
	public ErrorStructure  handleActorsNOtFound(ActorsNotFoundException ex)
	{
		return ErrorStructure.create(404,ex.getMessage(),"actors not present");
	}

}
